$(function(){

    var swiper = new Swiper('#visual .swiper', {
      
      loop: true,
      navigation: {
        nextEl: '#visual .swiper-button-next',
        prevEl: '#visual .swiper-button-prev',
      },
    
     
    });
  
    var swiper = new Swiper('#exclusive .swiper', {
      
      loop: true,
      navigation: {
        nextEl: '#exclusive .swiper-button-next',
        prevEl: '#exclusive .swiper-button-prev',
      },
    
     
    });
  
  });